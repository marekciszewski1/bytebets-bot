import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { coinflipPayout, coinflipWinProbability } from "../src/games/coinflip.js";
import {
  diceMultiplier,
  dicePayout,
  diceWinProbability,
  diceWon,
  validateDiceTarget,
} from "../src/games/dice.js";

describe("coinflip", () => {
  it("pays 2x on win", () => {
    assert.equal(coinflipPayout(50, true), 100);
    assert.equal(coinflipPayout(50, false), 0);
  });

  it("has 50% win probability", () => {
    assert.equal(coinflipWinProbability(), 0.5);
  });
});

describe("dice under/over", () => {
  it("validates targets", () => {
    assert.equal(validateDiceTarget(1), false);
    assert.equal(validateDiceTarget(50), true);
    assert.equal(validateDiceTarget(100), false);
  });

  it("computes under probability", () => {
    assert.equal(diceWinProbability(50, "under"), 0.49);
    assert.equal(diceWinProbability(60, "under"), 0.59);
  });

  it("computes over probability", () => {
    assert.equal(diceWinProbability(60, "over"), 0.4);
  });

  it("applies house edge to multiplier", () => {
    const mult = diceMultiplier(50, "under", 100);
    assert.ok(mult > 1.9 && mult < 2.1);
  });

  it("resolves wins", () => {
    assert.equal(diceWon(49, 50, "under"), true);
    assert.equal(diceWon(50, 50, "under"), false);
    assert.equal(diceWon(61, 60, "over"), true);
  });

  it("floors payout", () => {
    const mult = 1.98;
    assert.equal(dicePayout(10, true, mult), 19);
    assert.equal(dicePayout(10, false, mult), 0);
  });
});
