# Put this bot on GitHub (Windows)

## 1. Download the zip

Download **`bytebets-discord-bot-github.zip`** from this agent chat (files/artifacts) or from your Cursor codebase file list on branch **`main`**.

## 2. Unzip

Extract to a folder, e.g. `C:\Users\You\Documents\bytebets-discord-bot`

## 3. Upload to GitHub (pick one)

### Option A — GitHub Desktop (easiest)

1. Install https://desktop.github.com/ and sign in.
2. **File → Add local repository** → pick the unzipped folder.
3. If needed, **create a repository** in that folder.
4. **Publish repository** → name `discord-bot` → **Publish**.

### Option B — GitHub website (no Desktop)

1. Open https://github.com/marekciszewski/discord-bot (or create an empty repo).
2. Click **Add file** → **Upload files**.
3. Drag the **unzipped folder contents** (`src`, `package.json`, `render.yaml`, etc.) into the page — not the zip file.
4. Commit message: `Add Discord bot` → **Commit changes**.

Your code is now on GitHub.

## 5. Render

1. Render dashboard → your worker → connect repo **discord-bot**, branch **main**
2. Env vars: `DISCORD_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
3. **Manual Deploy**

## 6. Supabase (once)

Run `supabase/migrations/001_bytebets_core.sql` in Supabase SQL Editor if you have not already.
