import {
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
} from "discord.js";
import { config } from "../config.js";
import {
  AccountSuspendedError,
  claimDaily,
  DailyNotReadyError,
  ensurePlayer,
  fetchLeaderboard,
  fetchRecentBets,
  InsufficientBalanceError,
  InvalidWagerError,
  recordBet,
} from "../db/players.js";
import { coinflipPayout, flipCoin, type CoinSide } from "../games/coinflip.js";
import {
  classicDicePayout,
  diceMultiplier,
  dicePayout,
  diceWinProbability,
  diceWon,
  formatDiceMultiplier,
  rollDice100,
  rollDiceClassic,
  type DiceDirection,
} from "../games/dice.js";
import { isSupabaseConfigured } from "../db/supabase.js";
import { logger } from "../utils/logger.js";

const BRAND = "ByteBets";
const STARTING_HINT =
  "Play-money only — no real-money prizes. Run `/daily` if you need credits.";

function usernameFrom(interaction: ChatInputCommandInteraction): string {
  return interaction.user.displayName ?? interaction.user.username;
}

function requireDatabase(interaction: ChatInputCommandInteraction): boolean {
  if (isSupabaseConfigured()) return true;
  void interaction.reply({
    content:
      "Database is not configured on the host. Set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, then run migrations in `supabase/migrations/`.",
    flags: MessageFlags.Ephemeral,
  });
  return false;
}

function validateWager(amount: number): string | null {
  if (amount < config.minBet || amount > config.maxBet) {
    return `Wager must be between **${config.minBet}** and **${config.maxBet}** credits.`;
  }
  return null;
}

async function replyWagerError(
  interaction: ChatInputCommandInteraction,
  message: string
): Promise<void> {
  await interaction.reply({
    content: message,
    flags: MessageFlags.Ephemeral,
  });
}

function brandColorWin(): number {
  return 0x57f287;
}

function brandColorLoss(): number {
  return 0xed4245;
}

function brandColorNeutral(): number {
  return 0x5865f2;
}

export async function handleCommand(
  interaction: ChatInputCommandInteraction
): Promise<void> {
  logger.debug("command", {
    command: interaction.commandName,
    userId: interaction.user.id,
  });

  switch (interaction.commandName) {
    case "ping":
      await handlePing(interaction);
      break;
    case "help":
      await handleHelp(interaction);
      break;
    case "register":
      await handleRegister(interaction);
      break;
    case "balance":
      await handleBalance(interaction);
      break;
    case "profile":
      await handleProfile(interaction);
      break;
    case "stats":
      await handleStats(interaction);
      break;
    case "history":
      await handleHistory(interaction);
      break;
    case "daily":
      await handleDaily(interaction);
      break;
    case "leaderboard":
      await handleLeaderboard(interaction);
      break;
    case "coinflip":
      await handleCoinflip(interaction);
      break;
    case "dice":
      await handleDice(interaction);
      break;
    case "dice-classic":
      await handleDiceClassic(interaction);
      break;
    default:
      await interaction.reply({
        content: "Unknown command.",
        flags: MessageFlags.Ephemeral,
      });
  }
}

async function handlePing(interaction: ChatInputCommandInteraction): Promise<void> {
  const dbOk = isSupabaseConfigured();
  const sent = Date.now();
  await interaction.reply("Pong!");
  const latency = Date.now() - sent;
  await interaction.editReply(
    [
      `Pong! Round-trip: ${latency}ms · API: ${Math.round(interaction.client.ws.ping)}ms`,
      `Health: Discord OK · Supabase ${dbOk ? "configured" : "missing env"}`,
    ].join("\n")
  );
}

async function handleHelp(interaction: ChatInputCommandInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setTitle(`${BRAND} — play-money Discord casino`)
    .setDescription(
      [
        "Virtual credits only. Grow your community with leaderboards and fair mini-games.",
        "",
        "**Wallet:** `/register` · `/balance` · `/daily` · `/profile` · `/stats` · `/history`",
        "**Leaderboards:** `/leaderboard`",
        "**Games:** `/coinflip` · `/dice` · `/dice-classic`",
        "",
        `Bet limits: **${config.minBet}–${config.maxBet}** credits per round.`,
        "",
        "Roadmap: mines, crash, blackjack, roulette, rakeback, provably fair — see repo docs.",
        "",
        "Real-money gambling and licensed slot brands require legal review and provider deals.",
      ].join("\n")
    )
    .setColor(brandColorNeutral());

  await interaction.reply({ embeds: [embed] });
}

async function handleRegister(
  interaction: ChatInputCommandInteraction
): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const player = await ensurePlayer(interaction.user.id, usernameFrom(interaction));
  await interaction.reply({
    content: [
      `Welcome to **${BRAND}**, ${usernameFrom(interaction)}!`,
      `Starting balance: **${player.balance}** credits.`,
      `Try \`/daily\`, \`/coinflip\`, or \`/dice\`.`,
      STARTING_HINT,
    ].join("\n"),
    flags: MessageFlags.Ephemeral,
  });
}

async function handleBalance(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const player = await ensurePlayer(interaction.user.id, usernameFrom(interaction));
  const pnl = player.total_profit;
  const pnlLabel = pnl >= 0 ? `+${pnl}` : `${pnl}`;

  const embed = new EmbedBuilder()
    .setTitle(`${usernameFrom(interaction)} — balance`)
    .addFields(
      { name: "Balance", value: `${player.balance} credits`, inline: true },
      { name: "Total wagered", value: `${player.total_wagered}`, inline: true },
      { name: "PNL (profit)", value: pnlLabel, inline: true }
    )
    .setFooter({ text: STARTING_HINT })
    .setColor(brandColorWin());

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

async function handleProfile(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const player = await ensurePlayer(interaction.user.id, usernameFrom(interaction));
  const gamesPlayed = player.games_played ?? 0;
  const biggestWin = player.biggest_win ?? 0;
  const biggestLoss = player.biggest_loss ?? 0;
  const createdAt = player.created_at
    ? `<t:${Math.floor(new Date(player.created_at).getTime() / 1000)}:D>`
    : "—";

  const embed = new EmbedBuilder()
    .setTitle(`${player.discord_username} — profile`)
    .setDescription(`Member since ${createdAt}`)
    .addFields(
      { name: "Balance", value: `${player.balance}`, inline: true },
      { name: "Games played", value: `${gamesPlayed}`, inline: true },
      { name: "Net PNL", value: `${player.total_profit}`, inline: true },
      { name: "Biggest win", value: `${biggestWin}`, inline: true },
      { name: "Biggest loss", value: `${biggestLoss}`, inline: true },
      { name: "Total wagered", value: `${player.total_wagered}`, inline: true }
    )
    .setColor(brandColorNeutral());

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

async function handleStats(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const player = await ensurePlayer(interaction.user.id, usernameFrom(interaction));
  const gamesPlayed = player.games_played ?? 0;
  const totalWon = player.total_won ?? 0;
  const totalLost = player.total_lost ?? 0;
  const avgBet =
    gamesPlayed > 0 ? Math.floor(player.total_wagered / gamesPlayed) : 0;

  const embed = new EmbedBuilder()
    .setTitle("Performance stats")
    .addFields(
      { name: "Total wagered", value: `${player.total_wagered}`, inline: true },
      { name: "Total won (net on wins)", value: `${totalWon}`, inline: true },
      { name: "Total lost", value: `${totalLost}`, inline: true },
      { name: "Average bet", value: `${avgBet}`, inline: true },
      { name: "Net PNL", value: `${player.total_profit}`, inline: true },
      { name: "Games", value: `${gamesPlayed}`, inline: true }
    )
    .setFooter({ text: "PNL = payouts − wagers across all settled games" })
    .setColor(brandColorNeutral());

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

async function handleHistory(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const count = interaction.options.getInteger("count") ?? 10;
  const rows = await fetchRecentBets(interaction.user.id, count);

  if (rows.length === 0) {
    await interaction.reply({
      content: "No bets yet. Try `/coinflip` or `/dice`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const lines = rows.map((row) => {
    const ts = Math.floor(new Date(row.created_at).getTime() / 1000);
    const sign = row.profit >= 0 ? "+" : "";
    return `<t:${ts}:R> · **${row.game}** · wager ${row.wager} → ${sign}${row.profit}`;
  });

  const embed = new EmbedBuilder()
    .setTitle("Recent bets")
    .setDescription(lines.join("\n"))
    .setColor(brandColorNeutral());

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}

async function handleDaily(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  try {
    const { newBalance } = await claimDaily(
      interaction.user.id,
      usernameFrom(interaction),
      config.dailyAmount
    );
    await interaction.reply({
      content: `Daily claimed: **+${config.dailyAmount} credits**. New balance: **${newBalance}**.`,
      flags: MessageFlags.Ephemeral,
    });
  } catch (error) {
    if (error instanceof DailyNotReadyError) {
      await interaction.reply({
        content: "Daily already claimed. Come back in 24 hours.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    throw error;
  }
}

async function handleLeaderboard(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const metric = interaction.options.getString("metric", true) as
    | "wagered"
    | "profit"
    | "games";
  const rows = await fetchLeaderboard(metric, 10);

  if (rows.length === 0) {
    await interaction.reply("No players yet. Use `/daily` or `/coinflip` to get on the board.");
    return;
  }

  const title =
    metric === "wagered"
      ? "Leaderboard — wagered"
      : metric === "profit"
        ? "Leaderboard — profit (PNL)"
        : "Leaderboard — games played";

  const lines = rows.map((row, index) => {
    const value =
      metric === "wagered"
        ? row.total_wagered
        : metric === "profit"
          ? row.total_profit
          : row.games_played;
    return `**${index + 1}.** ${row.discord_username} — **${value}**`;
  });

  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(lines.join("\n"))
    .setColor(0xfee75c);

  await interaction.reply({ embeds: [embed] });
}

async function handleCoinflip(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const amount = interaction.options.getInteger("amount", true);
  const wagerError = validateWager(amount);
  if (wagerError) {
    await replyWagerError(interaction, wagerError);
    return;
  }

  const side = interaction.options.getString("side", true) as CoinSide;

  const outcome = flipCoin();
  const won = outcome === side;
  const payout = coinflipPayout(amount, won);

  try {
    const { newBalance, profit } = await recordBet({
      discordId: interaction.user.id,
      username: usernameFrom(interaction),
      game: "coinflip",
      wager: amount,
      payout,
      metadata: { pick: side, outcome, won },
    });

    const embed = new EmbedBuilder()
      .setTitle(won ? "Coinflip — win" : "Coinflip — loss")
      .setDescription(`Coin landed on **${outcome}** (you picked **${side}**).`)
      .addFields(
        { name: "Wager", value: `${amount}`, inline: true },
        { name: "Payout", value: `${payout}`, inline: true },
        { name: "PNL", value: `${profit >= 0 ? "+" : ""}${profit}`, inline: true },
        { name: "Balance", value: `${newBalance}`, inline: true }
      )
      .setColor(won ? brandColorWin() : brandColorLoss());

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    await handleBetError(interaction, error);
  }
}

async function handleDice(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const amount = interaction.options.getInteger("amount", true);
  const wagerError = validateWager(amount);
  if (wagerError) {
    await replyWagerError(interaction, wagerError);
    return;
  }

  const target = interaction.options.getInteger("target", true);
  const direction = interaction.options.getString("direction", true) as DiceDirection;

  const winProb = diceWinProbability(target, direction);
  const multiplier = diceMultiplier(target, direction, config.houseEdgeBps);
  const roll = rollDice100();
  const won = diceWon(roll, target, direction);
  const payout = dicePayout(amount, won, multiplier);

  try {
    const { newBalance, profit } = await recordBet({
      discordId: interaction.user.id,
      username: usernameFrom(interaction),
      game: "dice",
      wager: amount,
      payout,
      metadata: {
        mode: "under_over",
        target,
        direction,
        roll,
        won,
        multiplier,
        winProb,
      },
    });

    const embed = new EmbedBuilder()
      .setTitle(won ? "Dice — win" : "Dice — loss")
      .setDescription(
        [
          `Rolled **${roll}** (bet **${direction} ${target}**).`,
          `Win chance ~${(winProb * 100).toFixed(1)}% · multiplier ${formatDiceMultiplier(multiplier)}`,
        ].join("\n")
      )
      .addFields(
        { name: "Wager", value: `${amount}`, inline: true },
        { name: "Payout", value: `${payout}`, inline: true },
        { name: "PNL", value: `${profit >= 0 ? "+" : ""}${profit}`, inline: true },
        { name: "Balance", value: `${newBalance}`, inline: true }
      )
      .setColor(won ? brandColorWin() : brandColorLoss());

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    await handleBetError(interaction, error);
  }
}

async function handleDiceClassic(
  interaction: ChatInputCommandInteraction
): Promise<void> {
  if (!requireDatabase(interaction)) return;

  const amount = interaction.options.getInteger("amount", true);
  const wagerError = validateWager(amount);
  if (wagerError) {
    await replyWagerError(interaction, wagerError);
    return;
  }

  const guess = interaction.options.getInteger("guess", true);

  const roll = rollDiceClassic();
  const won = roll === guess;
  const payout = classicDicePayout(amount, won);

  try {
    const { newBalance, profit } = await recordBet({
      discordId: interaction.user.id,
      username: usernameFrom(interaction),
      game: "dice-classic",
      wager: amount,
      payout,
      metadata: { guess, roll, won },
    });

    const embed = new EmbedBuilder()
      .setTitle(won ? "Dice classic — win" : "Dice classic — loss")
      .setDescription(`Rolled **${roll}** (you guessed **${guess}**).`)
      .addFields(
        { name: "Wager", value: `${amount}`, inline: true },
        { name: "Payout", value: `${payout}`, inline: true },
        { name: "PNL", value: `${profit >= 0 ? "+" : ""}${profit}`, inline: true },
        { name: "Balance", value: `${newBalance}`, inline: true }
      )
      .setColor(won ? brandColorWin() : brandColorLoss());

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    await handleBetError(interaction, error);
  }
}

async function handleBetError(
  interaction: ChatInputCommandInteraction,
  error: unknown
): Promise<void> {
  if (error instanceof InsufficientBalanceError) {
    await interaction.reply({
      content: `Not enough credits. Try \`/daily\` or lower the wager. ${STARTING_HINT}`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (error instanceof InvalidWagerError) {
    await interaction.reply({
      content: `Invalid wager. Limits: **${config.minBet}–${config.maxBet}** credits.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (error instanceof AccountSuspendedError) {
    await interaction.reply({
      content: "This account is suspended. Contact a server admin.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  throw error;
}
