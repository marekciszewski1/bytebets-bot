import { SlashCommandBuilder } from "discord.js";

export const commandBuilders = [
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check if the bot is online"),
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("ByteBets command overview (play-money casino)"),
  new SlashCommandBuilder()
    .setName("register")
    .setDescription("Create your play-money wallet (also auto-created on first play)"),
  new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Show your play-money balance and stats"),
  new SlashCommandBuilder()
    .setName("profile")
    .setDescription("Player profile and lifetime statistics"),
  new SlashCommandBuilder()
    .setName("stats")
    .setDescription("Detailed performance summary"),
  new SlashCommandBuilder()
    .setName("history")
    .setDescription("Recent bets (last 10)")
    .addIntegerOption((option) =>
      option
        .setName("count")
        .setDescription("How many bets to show (max 25)")
        .setMinValue(1)
        .setMaxValue(25)
    ),
  new SlashCommandBuilder()
    .setName("daily")
    .setDescription("Claim free play credits (once every 24 hours)"),
  new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("Top players")
    .addStringOption((option) =>
      option
        .setName("metric")
        .setDescription("Ranking metric")
        .setRequired(true)
        .addChoices(
          { name: "Wagered", value: "wagered" },
          { name: "Profit (PNL)", value: "profit" },
          { name: "Games played", value: "games" }
        )
    ),
  new SlashCommandBuilder()
    .setName("coinflip")
    .setDescription("50/50 coinflip — 2× payout")
    .addIntegerOption((option) =>
      option
        .setName("amount")
        .setDescription("Credits to wager")
        .setRequired(true)
        .setMinValue(1)
    )
    .addStringOption((option) =>
      option
        .setName("side")
        .setDescription("Heads or tails")
        .setRequired(true)
        .addChoices(
          { name: "Heads", value: "heads" },
          { name: "Tails", value: "tails" }
        )
    ),
  new SlashCommandBuilder()
    .setName("dice")
    .setDescription("Roll 1–100 — bet under/over a target")
    .addIntegerOption((option) =>
      option
        .setName("amount")
        .setDescription("Credits to wager")
        .setRequired(true)
        .setMinValue(1)
    )
    .addIntegerOption((option) =>
      option
        .setName("target")
        .setDescription("Target number (2–99)")
        .setRequired(true)
        .setMinValue(2)
        .setMaxValue(99)
    )
    .addStringOption((option) =>
      option
        .setName("direction")
        .setDescription("Roll under or over the target")
        .setRequired(true)
        .addChoices(
          { name: "Under", value: "under" },
          { name: "Over", value: "over" }
        )
    ),
  new SlashCommandBuilder()
    .setName("dice-classic")
    .setDescription("Guess 1–6 — 5× payout on exact hit")
    .addIntegerOption((option) =>
      option
        .setName("amount")
        .setDescription("Credits to wager")
        .setRequired(true)
        .setMinValue(1)
    )
    .addIntegerOption((option) =>
      option
        .setName("guess")
        .setDescription("Your guess")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(6)
    ),
];

export const commands = commandBuilders.map((c) => c.toJSON());
