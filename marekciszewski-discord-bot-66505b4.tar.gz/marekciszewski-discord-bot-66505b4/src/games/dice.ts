export type DiceDirection = "under" | "over";

const DICE_MIN_TARGET = 2;
const DICE_MAX_TARGET = 99;

/** Inclusive roll 1–100. */
export function rollDice100(): number {
  return Math.floor(Math.random() * 100) + 1;
}

export function validateDiceTarget(target: number): boolean {
  return (
    Number.isInteger(target) &&
    target >= DICE_MIN_TARGET &&
    target <= DICE_MAX_TARGET
  );
}

/** Win probability for roll-under / roll-over on 1–100. */
export function diceWinProbability(
  target: number,
  direction: DiceDirection
): number {
  if (!validateDiceTarget(target)) return 0;
  if (direction === "under") {
    return (target - 1) / 100;
  }
  return (100 - target) / 100;
}

/** Multiplier with house edge in basis points (100 bps = 1%). */
export function diceMultiplier(
  target: number,
  direction: DiceDirection,
  houseEdgeBps: number
): number {
  const prob = diceWinProbability(target, direction);
  if (prob <= 0) return 0;
  const edge = houseEdgeBps / 10_000;
  return (1 - edge) / prob;
}

export function diceWon(
  roll: number,
  target: number,
  direction: DiceDirection
): boolean {
  if (direction === "under") return roll < target;
  return roll > target;
}

export function dicePayout(
  wager: number,
  won: boolean,
  multiplier: number
): number {
  if (!won) return 0;
  return Math.floor(wager * multiplier);
}

export function formatDiceMultiplier(multiplier: number): string {
  return `${multiplier.toFixed(2)}×`;
}

/** Classic 1–6 guess (legacy quick game). */
export function rollDiceClassic(): number {
  return Math.floor(Math.random() * 6) + 1;
}

export function classicDicePayout(wager: number, won: boolean): number {
  return won ? wager * 5 : 0;
}
