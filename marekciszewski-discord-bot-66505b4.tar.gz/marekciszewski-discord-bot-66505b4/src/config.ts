function readInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) ? n : fallback;
}

/** Play-money limits (also enforced in Supabase when migration 002 is applied). */
export const config = {
  dailyAmount: readInt("DAILY_CREDIT_AMOUNT", 500),
  minBet: readInt("MIN_BET", 1),
  maxBet: readInt("MAX_BET", 100),
  houseEdgeBps: readInt("HOUSE_EDGE_BPS", 100),
} as const;
