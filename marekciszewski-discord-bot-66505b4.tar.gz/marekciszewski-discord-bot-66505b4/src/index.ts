import "dotenv/config";
import { Client, Events, GatewayIntentBits } from "discord.js";
import { handleCommand } from "./commands/handlers.js";
import { isSupabaseConfigured } from "./db/supabase.js";
import { logger } from "./utils/logger.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  logger.error("startup.missing_token", { hint: "Set DISCORD_TOKEN in environment" });
  process.exit(1);
}

if (!isSupabaseConfigured()) {
  logger.warn("startup.supabase_missing", {
    hint: "Economy commands fail until SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are set",
  });
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, (readyClient) => {
  logger.info("discord.ready", { tag: readyClient.user.tag });
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    await handleCommand(interaction);
  } catch (error) {
    logger.error("command.failed", {
      command: interaction.commandName,
      userId: interaction.user.id,
      error: error instanceof Error ? error.message : String(error),
    });
    const message = "Something went wrong running that command.";
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: message, flags: 64 });
    } else {
      await interaction.reply({ content: message, flags: 64 });
    }
  }
});

await client.login(token);
