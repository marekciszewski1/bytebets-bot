-- Extended player stats, bet limits, and bet history helpers.

alter table public.players
  add column if not exists display_name text not null default '',
  add column if not exists games_played bigint not null default 0 check (games_played >= 0),
  add column if not exists total_won bigint not null default 0 check (total_won >= 0),
  add column if not exists total_lost bigint not null default 0 check (total_lost >= 0),
  add column if not exists biggest_win bigint not null default 0,
  add column if not exists biggest_loss bigint not null default 0,
  add column if not exists account_status text not null default 'active'
    check (account_status in ('active', 'suspended'));

create table if not exists public.platform_settings (
  key text primary key,
  value bigint not null,
  updated_at timestamptz not null default now()
);

insert into public.platform_settings (key, value)
values
  ('min_bet', 1),
  ('max_bet', 100)
on conflict (key) do nothing;

create or replace function public.ensure_player(
  p_discord_id text,
  p_discord_username text
)
returns public.players
language plpgsql
security definer
set search_path = public
as $$
declare
  row public.players;
begin
  insert into public.players (discord_id, discord_username, display_name)
  values (
    p_discord_id,
    coalesce(p_discord_username, ''),
    coalesce(p_discord_username, '')
  )
  on conflict (discord_id) do update
    set
      discord_username = excluded.discord_username,
      display_name = coalesce(nullif(excluded.display_name, ''), public.players.display_name)
  returning * into row;

  return row;
end;
$$;

create or replace function public.get_bet_limits()
returns table (min_bet bigint, max_bet bigint)
language sql
security definer
set search_path = public
stable
as $$
  select
    coalesce((select value from public.platform_settings where key = 'min_bet'), 1::bigint),
    coalesce((select value from public.platform_settings where key = 'max_bet'), 100::bigint);
$$;

create or replace function public.record_bet(
  p_discord_id text,
  p_discord_username text,
  p_game text,
  p_wager bigint,
  p_payout bigint,
  p_metadata jsonb default '{}'
)
returns table (new_balance bigint, profit bigint)
language plpgsql
security definer
set search_path = public
as $$
declare
  pl public.players;
  v_profit bigint;
  v_min bigint;
  v_max bigint;
begin
  select min_bet, max_bet into v_min, v_max from public.get_bet_limits();

  if p_wager < v_min or p_wager > v_max then
    raise exception 'invalid_wager';
  end if;

  pl := public.ensure_player(p_discord_id, p_discord_username);

  if pl.account_status <> 'active' then
    raise exception 'account_suspended';
  end if;

  if pl.balance < p_wager then
    raise exception 'insufficient_balance';
  end if;

  v_profit := p_payout - p_wager;

  update public.players
  set
    balance = balance - p_wager + p_payout,
    total_wagered = total_wagered + p_wager,
    total_profit = total_profit + v_profit,
    games_played = games_played + 1,
    total_won = total_won + case when v_profit > 0 then v_profit else 0 end,
    total_lost = total_lost + case when v_profit < 0 then -v_profit else 0 end,
    biggest_win = greatest(biggest_win, case when v_profit > 0 then v_profit else 0 end),
    biggest_loss = greatest(biggest_loss, case when v_profit < 0 then -v_profit else 0 end)
  where id = pl.id
  returning balance into new_balance;

  insert into public.bets (player_id, game, wager, payout, profit, metadata)
  values (pl.id, p_game, p_wager, p_payout, v_profit, coalesce(p_metadata, '{}'));

  profit := v_profit;
  return next;
end;
$$;

create or replace function public.fetch_recent_bets(
  p_discord_id text,
  p_limit int default 10
)
returns table (
  game text,
  wager bigint,
  payout bigint,
  profit bigint,
  metadata jsonb,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = public
stable
as $$
declare
  pl public.players;
begin
  select * into pl from public.players where discord_id = p_discord_id;
  if pl.id is null then
    return;
  end if;
  return query
  select b.game, b.wager, b.payout, b.profit, b.metadata, b.created_at
  from public.bets b
  where b.player_id = pl.id
  order by b.created_at desc
  limit greatest(1, least(p_limit, 25));
end;
$$;
